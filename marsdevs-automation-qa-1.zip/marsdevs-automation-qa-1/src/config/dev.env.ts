export const devEnv = {
  baseURL: 'https://www.saucedemo.com/',
  username: 'standard_user',
  password: 'secret_sauce',
  envName: 'dev'
};